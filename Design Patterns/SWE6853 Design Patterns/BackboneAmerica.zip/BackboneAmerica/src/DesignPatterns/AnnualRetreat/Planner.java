package DesignPatterns.AnnualRetreat;

public interface Planner {
    String plan();
}
