package DesignPatterns.UserRecord;

public enum UserType {
    CLIENT, GUEST, PROSPECT
}
